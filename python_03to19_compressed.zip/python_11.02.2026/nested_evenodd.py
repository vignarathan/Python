num=int(input("Enter the Number : "))
if(num>0):
    if((num%2)==0):
        print(num,"is a even number")
    else:
        print(num,"is a odd number")
else:
    print("It's a negative value")