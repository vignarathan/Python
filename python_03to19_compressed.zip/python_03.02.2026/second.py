id=1003
name="Vignarathan"
age=21
print("my name is",name)
print("my id is",id)
print("my age is",age)