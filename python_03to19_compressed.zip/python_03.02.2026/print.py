name="vig"
print(type(name))

pen=type(name)
print(pen)

id=1003
print(type(id))

ids=type(id)
print(ids)

x=17
print("my age is"+str(x))
