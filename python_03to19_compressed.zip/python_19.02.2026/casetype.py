s="    Welcome to YarlIT    "
print(len(s))
print(s)
print(s.lower())
print(s.upper())
print(s.title())
print(s.capitalize())
print(s.swapcase())
print("_________________________________")
print("isalpha :",s.isalpha())
print("isdigit :",s.isdigit())
print("islower :",s.islower())
print("isupper :",s.isupper())
print("isspace :",s.isspace())
print("_________________________________")
print(s.startswith('Welcome'))
print(s.endswith('t'))
print("_________________________________")
print(s.find('to'))
print(s.find('hello'))
print("_________________________________")
print(s.index('Y'))
#print(s.index('python'))
print("_________________________________")
print(s.count('t'))
print(s.replace("YarlIT","python"))
print(s.strip())  #removes both side spaces
print(s.lstrip())  #removes left side space
print(s.rstrip())  #removes right side space
print(s.split())   #split words with words
print("_________________________________")
r="Welcome to YarlIT"
print(r[0])
print(r[1])
print(r[2])
#print(r[3,1])
print(r[-1])
print(r[-5])
print(r[:5])
print(r[2:])
print(r[2:5])
print(r[0:8])
print(r[8:10])
print(r[11:18])






