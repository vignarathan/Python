subjects=["Maths","Science","Tamil","ICT","English","History"]
for x in range(len(subjects)):
    print(subjects[x])
    
print("*****************")
x=0    
while x<len(subjects):
    print(subjects[x])
    x+=1