myvar=10
print(Myvar)
