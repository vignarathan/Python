x=int(input("Enter Number1 : "))
y=int(input("Enter Number2 : "))

print("Addition(+) \t\t:",(x+y))
print("Subtraction(-) \t\t:",(x-y))
print("Multiplication(*) \t:",(x*y))
print("Division(/) \t\t:",(x/y))
print("Modulus(%) \t\t:",(x%y))
print("Exponentiation(**) \t:",(x**y))
print("Floor Division(//) \t:",(x//y))



