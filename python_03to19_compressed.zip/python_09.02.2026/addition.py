x=int(input("Enter First Number : "))
y=int(input("Enter Second Number : "))
z=x+y
print("Total :",z)

print("***************")
a=input("Enter Third Number : ")
b=input("Enter Fourth Number : ")
c=int(a)+int(b)
print("Total :",c)
