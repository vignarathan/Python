fname="Vignarathan"
lname="Sivalingam"
em="s.vikki@2026@gmail.com"
bpay=150000
print("**********************************************")
print("Employee Details")
print("**********************************************")
print("Full Name","\t:",fname,lname)
print("Email","\t\t:",em)
print("Basic Salary","\t:","Rs."+str(bpay))
print("**********************************************")

