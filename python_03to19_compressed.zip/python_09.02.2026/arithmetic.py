x=10
y=3
print("x+y=",(x+y))
print("x-y=",(x-y))
print("x*y=",(x*y))
print("x/y=",(x/y))
print("x**y=",(x**y))
print("x//y=",(x//y))