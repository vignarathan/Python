x=1
while x<5:
    print(x)
    x+=1
print(f"x={x}")#x=5