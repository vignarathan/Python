x=1
while True:
    print(x)
    x+=1 
 #output tends to infinity   