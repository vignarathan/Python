x=1
while x<=10:
    print(x)
    x+=1

print("***********")

y=10
while y>0:
    print(y)
    y-=1
