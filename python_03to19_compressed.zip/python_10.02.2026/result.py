x=int(input("Enter Your Marks : "))
if(x>=45):
    print("Pass")
else:
    print("Fail")