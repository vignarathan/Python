x=int(input("Enter Your Age :"))
if(150>=x>=0):
    if(x>=18):
        print("Eligible for Vote")
    else:
        print("Not eligible for Vote")
else:
    print("Invalid Age")