x=10
y=20

print("x==y \t:",(x==y))
print("x!=y \t:",(x!=y))
print("x>y \t:",(x>y))
print("x<y \t:",(x<y))
print("x>=y \t:",(x>=y))
print("x<=y \t:",(x<=y))

