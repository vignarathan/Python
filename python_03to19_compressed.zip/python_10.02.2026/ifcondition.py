num1=10
num2=30

if(num1>num2):
    print("num1 is greater than num2") 
else:
    print("num2 is greater than num")

