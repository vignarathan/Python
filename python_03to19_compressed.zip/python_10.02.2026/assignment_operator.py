x=10
print("x \t=",x)#10

x+=5
print("x+= \t=",x)#15

x-=5
print("x-= \t=",x)#10

x*=10
print("x*= \t=",x)#100

x/=2
print("x/= \t=",x)#50

x**=2
print("x**= \t=",x)#2500

x//=4
print("x//= \t=",x)#625

