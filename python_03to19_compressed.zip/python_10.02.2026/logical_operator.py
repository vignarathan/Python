x=True
y=False

print(x and y)#False
print(x or y)#True
print(not x)#False

x=10
y=20
                               
print(x>y and x<30)#False
print(x>y or y>5)#True
print(not(x==y))#True
