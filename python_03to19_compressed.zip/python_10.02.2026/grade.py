x=int(input("Enter Your Marks : "))
if(100>=x>=0):
    if(x>74):
        print("Result : A")
    elif(x>64):
        print("Result : B")
    elif(x>54):
        print("Result : C")
    elif(x>44):
        print("Result : S")
    else:
        print("Fail")
else:
    print("Invalid Marks")
    
    
    
    
    