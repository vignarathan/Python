i=1
is_bool=True

while is_bool:
    print(i)
    i+=1
    if i==11:
        is_bool=False
        