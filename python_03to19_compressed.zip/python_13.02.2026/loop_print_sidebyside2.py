i=0

while i<6:
    i+=1
    print(i,end=" ")