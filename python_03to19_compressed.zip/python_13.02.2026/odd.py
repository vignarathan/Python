num=1
while num<=10:
    if(num%2!=0):
        print(num)
    num+=1