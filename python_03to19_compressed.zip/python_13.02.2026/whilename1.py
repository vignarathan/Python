i=1
n_bool=True

while n_bool:
    print("S.Vignarathan")
    i+=1
    if i==11:
        n_bool=False
