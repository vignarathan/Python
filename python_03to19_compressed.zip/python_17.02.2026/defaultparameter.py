def printfullname(fname="yourname",lname="father'sname"):
    print(f"Full Name : {fname} {lname}")

printfullname()