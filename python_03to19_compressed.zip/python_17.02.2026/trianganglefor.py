for x in range(0,5):
    x=((x+1)*x)//2
    print(x,end=" ")
    