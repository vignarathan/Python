def printfullname(fname,lname):
    return fname+lname
    
fullname=printfullname("vignarathan","sivalingam")
print(fullname)