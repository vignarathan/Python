for x in range(1,6):
    if x%2==0:
        print("*",end=" ")
    else:
        print(x,end=" ")