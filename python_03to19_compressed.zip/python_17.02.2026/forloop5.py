for x in range(10):
    if x==5:
        continue
    print(x)