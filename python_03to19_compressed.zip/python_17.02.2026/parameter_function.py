def printmyname(name):
    print(f"My Name is {name}")

printmyname("vignarathan")
printmyname("vigna")
printmyname("rathan")
