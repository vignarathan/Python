for x in "jaffna":
    print(x)
print("")

for y in "vignarathan":
    print(y)