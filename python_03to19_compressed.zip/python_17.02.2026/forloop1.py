for x in range (5):
    print(x)
print(" ")
for x in range (1,5):
    print(x)
print("")
for x in range (5,10):
    print(x)
