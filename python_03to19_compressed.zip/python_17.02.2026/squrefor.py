for x in range(1,6):
    x=x*x
    print(x,end=" ")