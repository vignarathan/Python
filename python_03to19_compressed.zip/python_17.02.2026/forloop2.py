for x in range (1,10,2):
    print(x)
print("")

for y in range(10,0,-1):
    print(y)
    

"""for i in True:
    print(i)
    
  it can not use here, here range used not condition"""
