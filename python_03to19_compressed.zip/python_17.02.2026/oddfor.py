for x in range(3,10,2):
    print(x,end=" ")