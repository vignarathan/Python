def printMyname():
    print("My Name is S.Vignarathan")

printMyname() #calling function
printMyname() #calling function
printMyname() #calling function
