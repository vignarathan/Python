i=1
while i<6:
    i+=1
    if i==4:
        continue
    print(i)
