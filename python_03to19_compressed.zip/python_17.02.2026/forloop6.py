for x in range(1,10):
    if x%2==0:
        print(x,"-even number")
    else:
        print(x,"-odd number")
        
        