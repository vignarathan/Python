i=1
while i<6:
    print(i)
    if i==4:
        break
    i+=1