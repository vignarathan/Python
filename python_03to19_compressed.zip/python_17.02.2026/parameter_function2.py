def printfullname(fname,lname):
    print(f"Full Name : {fname} {lname}")

printfullname("Vignarathan","Sivalingam")