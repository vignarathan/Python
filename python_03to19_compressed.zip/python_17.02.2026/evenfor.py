for x in range(4,11,2):
    print(x,end=" ")