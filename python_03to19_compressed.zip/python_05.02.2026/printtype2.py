#type2
id=1003;
name="Vignarathan"
gr="10A"
ic=200412121313

print("-----------------------------","\n\tStudent Information","\n-----------------------------","\nStudent ID","\t:",id,"\nStudent Name","\t:",name,"\nGrade Name","\t:",gr,"\nNIC No","\t\t:",ic,"\n-----------------------------")

