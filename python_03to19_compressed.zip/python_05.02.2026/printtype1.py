#type1
id=1003;
name="Vignarathan"
gr="10A"
ic=200412121313

print("-----------------------------")
print("\tStudent Information")
print("-----------------------------")
print("Student ID","\t:",id)
print("Student Name","\t:",name)
print("Grade Name","\t:",gr)
print("NIC No","\t\t:",ic)
print("-----------------------------")
