#type3
id=1003;
name="Vignarathan"
gr="10A"
ic=200412121313

output=f"Student ID \t: {id}\nStudent Name \t: {name}\nGrade Name \t: {gr}\nNIC No \t\t: {ic}"
print("-----------------------------")
print("Student Information")
print("-----------------------------")
print(output)
print("-----------------------------")