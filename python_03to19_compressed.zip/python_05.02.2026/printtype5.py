#type5
id=1003;
name="Vignarathan"
gr="10A"
ic=200412121313


print("-----------------------------")
print("Student Information")
print("-----------------------------")
print("Student ID \t: %d\nStudent Name \t: %s\nGrade Name \t: %s\nNIC No \t\t: %d"%(id,name,gr,ic))
print("-----------------------------")